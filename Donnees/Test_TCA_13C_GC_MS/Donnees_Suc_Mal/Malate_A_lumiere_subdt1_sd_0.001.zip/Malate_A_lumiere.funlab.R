df=read.table(file.path(dirw,"Malate_A_lumiere.tsv"), header=TRUE)
head(df)