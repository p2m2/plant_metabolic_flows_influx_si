df=read.table(file.path(dirw,"Suc_Glu_A_sombre.tsv"), header=TRUE)
head(df)