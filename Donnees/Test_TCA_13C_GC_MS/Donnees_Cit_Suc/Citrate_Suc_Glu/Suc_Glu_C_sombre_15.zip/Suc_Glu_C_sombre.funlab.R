df=read.table(file.path(dirw,"Suc_Glu_C_sombre.tsv"), header=TRUE)
head(df)