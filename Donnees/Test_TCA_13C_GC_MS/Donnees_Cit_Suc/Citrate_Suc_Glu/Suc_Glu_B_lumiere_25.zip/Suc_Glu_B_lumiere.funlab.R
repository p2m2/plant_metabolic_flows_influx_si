df=read.table(file.path(dirw,"Suc_Glu_B_lumiere.tsv"), header=TRUE)
head(df)