df=read.table(file.path(dirw,"Suc_Glu_C_lumiere.tsv"), header=TRUE)
head(df)