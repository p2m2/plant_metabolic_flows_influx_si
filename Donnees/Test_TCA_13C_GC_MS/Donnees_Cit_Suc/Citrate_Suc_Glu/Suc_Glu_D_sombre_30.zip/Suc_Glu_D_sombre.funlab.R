df=read.table(file.path(dirw,"Suc_Glu_D_sombre.tsv"), header=TRUE)
head(df)