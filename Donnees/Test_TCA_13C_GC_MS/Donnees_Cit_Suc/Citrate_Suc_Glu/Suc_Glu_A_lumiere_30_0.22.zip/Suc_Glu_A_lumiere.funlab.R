df=read.table(file.path(dirw,"Suc_Glu_A_lumiere.tsv"), header=TRUE)
head(df)