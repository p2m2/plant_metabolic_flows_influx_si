df=read.table(file.path(dirw,"Suc_Glu_B_sombre.tsv"), header=TRUE)
head(df)