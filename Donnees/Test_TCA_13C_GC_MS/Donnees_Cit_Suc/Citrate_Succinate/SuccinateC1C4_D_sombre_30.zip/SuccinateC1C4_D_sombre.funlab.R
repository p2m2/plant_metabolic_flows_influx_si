df=read.table(file.path(dirw,"SuccinateC1C4_D_sombre.tsv"), header=TRUE)
head(df)