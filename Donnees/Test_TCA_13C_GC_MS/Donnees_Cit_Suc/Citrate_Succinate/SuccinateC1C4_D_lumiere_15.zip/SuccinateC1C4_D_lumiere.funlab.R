df=read.table(file.path(dirw,"SuccinateC1C4_D_lumiere.tsv"), header=TRUE)
head(df)