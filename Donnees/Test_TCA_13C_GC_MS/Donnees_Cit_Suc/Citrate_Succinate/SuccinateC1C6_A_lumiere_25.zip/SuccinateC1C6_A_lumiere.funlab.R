df=read.table(file.path(dirw,"SuccinateC1C6_A_lumiere.tsv"), header=TRUE)
head(df)