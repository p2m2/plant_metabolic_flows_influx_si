df=read.table(file.path(dirw,"SuccinateC1C4_B_sombre.tsv"), header=TRUE)
head(df)