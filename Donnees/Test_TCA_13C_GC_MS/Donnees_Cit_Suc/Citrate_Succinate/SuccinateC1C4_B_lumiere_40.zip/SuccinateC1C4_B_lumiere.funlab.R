df=read.table(file.path(dirw,"SuccinateC1C4_B_lumiere.tsv"), header=TRUE)
head(df)