df=read.table(file.path(dirw,"SuccinateC1C4_A_sombre.tsv"), header=TRUE)
head(df)