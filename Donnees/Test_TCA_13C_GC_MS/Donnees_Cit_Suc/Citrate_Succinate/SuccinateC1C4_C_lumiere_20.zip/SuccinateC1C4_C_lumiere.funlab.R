df=read.table(file.path(dirw,"SuccinateC1C4_C_lumiere.tsv"), header=TRUE)
head(df)