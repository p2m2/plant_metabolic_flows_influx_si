df=read.table(file.path(dirw,"Valiner_C_15.tsv"), header=TRUE)
head(df)