#library(dplyr)
#library(tidyr)

#donnes <- read.table("Supplemental Tables - Table S3.csv" , header = TRUE , sep = "," , dec = ".")
#head(donnes)
#print(donnes$Valine.M.1)

# data for linear interpolation of 'A#1' isotopomer: 1-exp(-0.5*t)
df=read.table(file.path(dirw,"Valiner_A_11.tsv"), header=TRUE)
head(df)

