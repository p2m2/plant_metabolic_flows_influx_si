df=read.table(file.path(dirw,"Valiner_B_7.tsv"), header=TRUE)
head(df)

