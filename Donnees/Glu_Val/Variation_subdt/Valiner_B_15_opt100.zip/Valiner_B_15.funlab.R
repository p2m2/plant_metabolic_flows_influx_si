df=read.table(file.path(dirw,"Valiner_B_15.tsv"), header=TRUE)
head(df)