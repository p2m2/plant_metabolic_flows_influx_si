df=read.table(file.path(dirw,"Valiner_A_15.tsv"), header=TRUE)
head(df)